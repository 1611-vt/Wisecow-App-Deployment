import psutil
import logging

# Set thresholds
CPU_THRESHOLD = 80.0
MEMORY_THRESHOLD = 80.0
DISK_THRESHOLD = 80.0

# Configure logging
logging.basicConfig(filename='system_health.log', level=logging.INFO)

def check_system_health():
    cpu_usage = psutil.cpu_percent(interval=1)
    memory = psutil.virtual_memory()
    disk = psutil.disk_usage('/')
    
    # Check and log if thresholds are exceeded
    if cpu_usage > CPU_THRESHOLD:
        logging.info(f"High CPU Usage: {cpu_usage}%")
    if memory.percent > MEMORY_THRESHOLD:
        logging.info(f"High Memory Usage: {memory.percent}%")
    if disk.percent > DISK_THRESHOLD:
        logging.info(f"High Disk Usage: {disk.percent}%")
    
    logging.info("System Health Check Completed")

check_system_health()

import requests
import logging

# URL of the application
APP_URL = 'http://wisecow.example.com'

# Configure logging
logging.basicConfig(filename='app_health.log', level=logging.INFO)

def check_application_health():
    try:
        response = requests.get(APP_URL, timeout=5)
        if response.status_code == 200:
            logging.info("Application is UP.")
        else:
            logging.info(f"Application is DOWN. Status code: {response.status_code}")
    except requests.exceptions.RequestException as e:
        logging.error(f"Application is DOWN. Error: {e}")

check_application_health()
